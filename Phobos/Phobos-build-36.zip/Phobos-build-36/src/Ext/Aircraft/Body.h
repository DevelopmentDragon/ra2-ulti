#pragma once
#include <AircraftClass.h>

// TODO: Implement proper extended AircraftClass.

class AircraftExt
{
public:
	static void FireBurst(AircraftClass* pThis, AbstractClass* pTarget, int shotNumber);
};

