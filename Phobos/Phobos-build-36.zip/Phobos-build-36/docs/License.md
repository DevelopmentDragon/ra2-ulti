# License

```{include} ../LICENSE.md
:relative-docs: docs/
:relative-images:
```
